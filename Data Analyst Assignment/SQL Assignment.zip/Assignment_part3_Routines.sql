#Q1

Delimiter //
CREATE PROCEDURE Order_status (IN in_monthname VARCHAR(50) , IN in_year INT )
Begin

SELECT ordernumber, orderdate, status FROM orders  
WHERE in_monthname = in_monthname AND in_year = in_year  ;

End //

Call Order_status ( 'Jan' , 2003);

#--------------------------------------------------------------#
#Q2.

Delimiter // 
CREATE PROCEDURE cancellations() 
BEGIN  
create table if not exists cancellations(
id int PRIMARY KEY auto_increment,  
customernumber int,  
orderNumber int,
comments VARCHAR(30),
FOREIGN KEY (customerNumber) REFERENCES customers(customerNumber) ,   
FOREIGN KEY (orderNumber) REFERENCES orders(orderNumber)
); 
 
insert into cancellations (customernumber,orderNumber,comments) 
select customerNumber,orderNumber, status from orders 
where status='Cancelled'; 

END //  

call cancellations() ;
SELECT * FROM assignment.cancellations; 

#/----------------------------------------------------//
#Q3

CREATE VIEW Purchase_status  as 
SELECT * from payments 
right join customers using (customernumber); 
 
DELIMITER // 
CREATE FUNCTION purchase_status(amount DECIMAL(10,2)) 
RETURNS VARCHAR(300)  DETERMINISTIC 
BEGIN  
 	DECLARE P_status varchar(300); 
 	IF amount < 25000 THEN SET P_status='Silver'; 
    
 	ELSEIF amount >50000 THEN SET P_status='Platinum';  
	
	ELSE SET P_status= 'Gold';  	
    
	END IF; 
    
	RETURN (P_status); 
    
 END // 

SELECT customername,customerNumber,purchase_status(amount) AS purchase_status from Purchase_status;

#/-----------------------------------------------------------------//

#Q4
delimiter //
CREATE PROCEDURE empd(custNo int )
BEGIN
DECLARE credit DECIMAL(10,2) DEFAULT 0;
DECLARE P_Status varchar(10);
DECLARE Update_condition CONDITION FOR SQLSTATE '22012';
if ( select 1
from (
select creditLimit,
case
when amount < 25000 then 'silver'
when amount between 25000 and 50000 then 'Gold'
when amount > 50000 then 'Platinum'
end as purchasestatus,a.customerNumber from payments a inner join customers b
on a.customerNumber=b.customerNumber) as a
where customerNumber=custNo and purchasestatus='Platinum' and creditLimit<100000
)=1 then
update customers
set creditlimit =100000
where customerNumber=custNo;
SIGNAL SQLSTATE '22012'
SET MESSAGE_TEXT ='credit is less than 100000';
elseif
( select 1
from (
select creditLimit,
case
when amount < 25000 then 'silver'
when amount between 25000 and 50000 then 'Gold'
when amount > 50000 then 'Platinum'
end as purchasestatus,a.customerNumber from payments a inner join customers b
on a.customerNumber=b.customerNumber) as a
where customerNumber=custNo and purchasestatus='silver' and creditLimit>60000
)=1 then
update customers
set creditlimit =60000
where customerNumber=custNo;
SIGNAL SQLSTATE '22012'
SET MESSAGE_TEXT ='credit is less than 60000';
end if;
commit;

END //

call empd(448);

#/-------------------------------------------------------------------//
#Q5.

On delete cascade
delimiter //
CREATE TRIGGER del_cascade
AFTER DELETE ON `movies`
FOR EACH ROW
BEGIN
delete from rentals
where movieid = old.id;
END //
-- On update cascade
delimiter //
CREATE  TRIGGER upd_cascade
AFTER UPDATE ON `movies`
FOR EACH ROW
BEGIN
update rentals set movieid = new.id
where movieid = old.id;
END //