#Q1 Create a database called 'assignment' 

CREATE DATABASE assignment;
#Q2. Create the tables from assignment_tables.sql and enter the records as specified in it.
CREATE TABLE test(
srno INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(10) NOT NULL);

SELECT * FROM test;

#Q.3 Create a table called authors with the following columns authorid , name

CREATE TABLE authors (
Authorid INT Not NULL AUTO_INCREMENT PRIMARY KEY , 
Name Varchar(100)
);

SELECT * from authors;

#/--------------------------------------------------------------------------------------------------------//

#a) Insert the following data into the table

INSERT INTO authors (name) VALUES 
('J K Rowling'), ('Thomas Hardy'),('Oscar Wilde'),('Sidney Sheldon'),('Alistair Maclean'),('Jane Autsen');

#b) Add a couple of authors of your choice

INSERT INTO authors (name) VALUES
('Eiichiro Oda'), ('Masashi Kishimoto'), ('Vyasa'), ('Valmiki');

SELECT * from authors;

#c) Change 'Alistair Maclean' to 'Alastair McNeal'

UPDATE authors SET Name = 'Alastair McNeal' WHERE Authorid = 5 ;

SELECT* FROM authors;

#/----------------------------------------------------------------------------//

#Q4. Create a table called Books with the following  columns bookid, title, authorid

CREATE TABLE books 
(bookid INT AUTO_INCREMENT PRIMARY KEY ,
title VARCHAR(100),
authorid INT
);

#Q4.a) Insert the following records 

Insert Into books values 
		(1,"Harry Potter and the Philosopher's Stone",1),
		(2,'Harry Potter and the Chamber of Secrets',1),
		(3,'Harry Potter and the Half-Blood Prince',1),
		(4,'Harry Potter and the Goblet of Fire',1),
		(5,'Night Without End',5),
		(6,'Fear is the Key',5),
		(7,'Where Eagles Dare',5),
		(8,'Sense and Sensibility',6),
		(9,'Pride and Prejudice',6),
		(10,'Emma',6),
		(11,'Random Book',22);
        
        SELECT * from Books;
        

#Q4.b) Delete 'Random Book' from the table.

DELETE FROM books WHERE bookid = 11;

#/-------------------------------------------------------------------------//

#Q5. Rename the table Books to Favbooks and Authors to Favauthors.

RENAME TABLE books to Favbooks, authors to favauthors;

#/---------------------------------------------------------------------------//

#Q6. Create the following tables. Use auto increment wherever applicable
	#A. Products

	CREATE TABLE Products1(
	product_id INT AUTO_INCREMENT PRIMARY KEY,
	product_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(50),
	supplier_id  INT ,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
    );
     
    #B. Suppliers
    
	CREATE TABLE Suppliers(
	supplier_id INT PRIMARY Key,
    supplier_name VARCHAR(100),
    location VARCHAR(100)
    );
        
    #C. Stock
  
	CREATE TABLE stock(
	Id INT PRIMARY KEY,
	product_id INT,
	balance_stock INT,
	FOREIGN KEY (product_id) REFERENCES products1 (product_id)
	);

#/-----------------------------------------------------------------------------------//

#Q7. Enter some records into the three tables.

insert into products1 values
(1, 'SFS', 'Packaging machine manufacturing industry',1),
(2,'Infinty','glass manufacturing company',2);

insert into stock values(1,1,5000),
(2,2,569);

INSERT INTO suppliers VALUES
(1,'Alicia Alarcon','India'),
(2,'Don	Draper','USA'),
(3,'Lizzie Moss','Africa'),
(4,'Eldon Chance','Russia');

SELECT * FROM suppliers;


#/---------------------------------------------------------//
	
#Q8. Modify the supplier table to make supplier name unique and not null.

ALTER TABLE suppliers MODIFY supplier_name VARCHAR(100) UNIQUE NOT NULL ;

#/-----------------------------------------------------------//

#Q9. Modify the emp table as follows
	#A. Add a column called deptno
		
        ALTER TABLE emp ADD COLUMN deptno INT ;
        
        SELECT * FROM emp;
        
	#B. Set the value of deptno in the following order
		
        UPDATE emp SET deptno = 20 WHERE emp_no % 2 =0 ;
        UPDATE emp set deptno = 30 where emp_no % 3 =0 ;
		UPDATE emp set deptno = 40 where emp_no % 4 =0 ;
        UPDATE emp set deptno = 50 where emp_no % 5 =0 ;
        UPDATE emp set deptno = 10 WHERE deptno IS NULL;
        
#/---------------------------------------------------------------//

#Q10. Create a unique, hash index on the emp_id column. 

CREATE UNIQUE INDEX harsh ON emp (emp_no);




