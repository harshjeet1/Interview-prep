#Q1. SELECT all employees in department 10 whose salary is greater than 3000. [table: employee]

SELECT empid , deptno , salary FROM employee WHERE salary > 3000 HAVING DEPTNO = 10;

#/------------------------------------------------------------------------------------//

#Q2. The grading of students based on the marks they have obtained is done as follows

SELECT id, name,if (marks >= 80 , 'Distinction80', if (marks >=50 ,'Firstclass','secondclass')) As Marks
from students ;

#a. How many students  have graduated with first class?

SELECT COUNT(marks) AS No_of_students from students WHERE marks >= 50 AND marks <= 80 ;

#b. How many students  have obtained distinction?  [table: students]

SELECT COUNT(marks) AS No_of_students from students WHERE marks >= 80 AND marks <= 100 ;

#/---------------------------------------------------------------------------------------------//

#Q3. Get a list of city names from station with even ID numbers only. Exclude duplicates from your answer.

SELECT DISTINCT(id) AS id, city from station 
where id  % 2 =0; #even

#where id  % 2 =1; -----(odd)
#/----------------------------------------------------------------------------------------------//

#Q4. Find the difference between the total number of city entries in the table and the number of distinct city entries in the table. In other words, if N is the number of city entries in station, and N1 is the number of distinct city names in station, write a query to find the value of N-N1 from station

#SELECT count(city) AS Total_cities FROM station; #501
#SELECT DISTINCT(count(city)) AS Total_cities FROM station;#501

select city = count(city) - count(DISTINCT(city)) as difference_between_the_total_number_of_cities  from station ; 

#/----------------------------------------------------------------------------------------------//
#Q5.a. Query the list of CITY names starting with vowels (i.e., a, e, i, o, or u) from STATION. Your result cannot contain duplicates

SELECT DISTINCT(city) FROM station WHERE LEFT(city, 1) IN ('a', 'e', 'i', 'o', 'u');

	#b
SELECT DISTINCT(city) FROM station WHERE Right(city, 1) IN ('a', 'e', 'i', 'o', 'u')
And LEFT(city, 1) IN ('a', 'e', 'i', 'o', 'u')  ;

	#c. Query the list of CITY names from STATION that do not start with vowels.

SELECT DISTINCT(city) FROM station WHERE left(city,1) NOT IN ('a', 'e', 'i', 'o', 'u'); 

	#d.
SELECT DISTINCT(city) FROM station WHERE Right(city, 1) NOT IN ('a', 'e', 'i', 'o', 'u')
And LEFT(city, 1) NOT IN ('a', 'e', 'i', 'o', 'u')  ;
#/-------------------------------------------------------------------------------------//

#Q7. Write a query that prints a list of employee names having a salary greater than $2000 per month who have been employed for less than 10 months. Sort your result by ascending emp_id. 

SELECT * from emp where salary > 2000 And hire_date < month(10) ORDER BY emp_no ASC ;

#/-----------------------------------------------------------------//
#Q8. 12. How much money does the company spend every month on salaries for each department? 

SELECT deptno , SUM(salary) FROM employee GROUP BY deptno;

#/------------------------------------------------------------------//

#Q9. How many cities in the CITY table have a Population larger than 100000. [table: city]

SELECT * FROM city WHERE population >= 100000;
#/-------------------------------------------------------------------------------------------//

#Q10. What is the total population of California? 

SELECT countrycode, district ,SUM(population) AS Total_population FROM city where district = 'california' ;

#/----------------------------------------------------------------------------------------//

#Q11. What is the average population of the districts in each country?

SELECT countrycode,AVG(population) AS Average_Population FROM city GROUP BY countrycode;




